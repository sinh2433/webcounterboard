<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title> HJ World! </title>

        <style>
            #test_btn1{
                border-top-left-radius: 5px;
                border-bottom-left-radius: 5px;
                margin-right:-7px;
            }
            #test_btn2{
                margin-right:-6px;
            }
            #test_btn3{
                border-top-right-radius: 5px;
                border-bottom-right-radius: 5px;
                margin-left:-1px;
            }

            #btn_group button{
                border: 0px solid white;
                background-color: rgba(0,0,0,0);
                color: white;
                padding: 5px;
            }
            #btn_group button:hover{
                color:blue;
                background-color: white;
            }
</style>

    </head>

    <body>
            <div style=" background-color:#832A95; font: 1.5em/1em Georgia ; color: white; border-top-left-radius: 10px;border-top-right-radius: 10px; height: 50px;">
                <div style="vertical-align: bottom; text-align: left; float: left; width:30%; line-height: 50px;">&nbsp;&nbsp;Menu</div>
                <div style="vertical-align: bottom; text-align: right; float: right; width:60%; font: 0.3em/1.5em Georgia; line-height: 50px;">Created by Dongwoo Jeong&nbsp;&nbsp;</div>
            </div>


            <div id="btn_group" style=" margin:0 auto; background-color: #9746A8;  border-bottom-left-radius: 10px; border-bottom-right-radius: 10px; height: 30px; vertical-align: middle; line-height: 30px">

                <!--&nbsp;&nbsp;<button onclick="location.href='https://hjworld.asuscomm.com:5001'" id="test_btn1">Connect NAS Web UI</button>&nbsp;&nbsp;
                <button onclick="location.href='http://155.230.153.106:3000/redmine'" id="test_btn2">LAB Redmine</button>&nbsp;&nbsp;
                <button onclick="location.href='http://rnd2.knu.ac.kr:8080/twiki/bin/view/Main/WebHome'" id="test_btn2">LAB Twiki</button>&nbsp;&nbsp;-->
                <button onclick="location.href='counter.php'" id="test_btn1">Web Counter board</button>&nbsp;&nbsp;
                <button onclick="location.href='run2.php'" id="test_btn3">Result List</button>

            </div>

    </body>
</html>
