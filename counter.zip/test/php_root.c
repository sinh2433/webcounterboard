#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>

int main (int argc, char **argv)
{
if (argc < 2)
{
printf("%s usage : %s <command of needed root right> <param1> <param2> ...\n", argv[0], argv[0]);
}
else
{
setuid (0); char szCmd[8000] = "";
int i;
for(i = 0; i < argc; i ++) {
if(i != 0) {
strcat(szCmd, *(argv+i));
strcat(szCmd, " ");
}
}
system (szCmd);
}
return 0;
}
