#include "spi.h"
#include "/usr/include/mariadb/mysql.h"


#define DB_HOST "127.0.0.1"
#define DB_USER "counter"
#define DB_PASS "webcounterboard"
#define DB_NAME "counter"
#define CHOP(x) x[strlen(x) - 1] = ' '

int main() {
    MYSQL       *connection=NULL, conn;
    MYSQL_RES   *sql_result;
    MYSQL_ROW   sql_row;
    int       query_stat; 

    char query[255] = "UPDATE counter SET stat = 1 WHERE counter.fname = '";
    
    mysql_init(&conn);

    connection = mysql_real_connect(&conn, DB_HOST, DB_USER, DB_PASS, DB_NAME, 3306, (char *)NULL, 0);

    if (connection == NULL)
    {
        fprintf(stderr, "Mysql connection error : %s", mysql_error(&conn));
        return 1;
    }


  FILE *fp;
  FILE *fr;
  int i;
  int n;
  int data[4096];
  int data_size;
  char fname[50];
  //char aaa[30];
  //char fn[100] = "/home/pi/Desktop/test/data/";
  char fn[100] = "data/";

  int period; //second
  int thr; //0~4095
  int pol; //0 is negative, 1 is positive

  setup_io();

  fp = fopen("setting.txt", "r");
  fscanf(fp, "%d %*s", &period); // period
  fscanf(fp, "%d %*s", &pol);  // polarity
  fscanf(fp, "%d %*s", &thr); // 
  fscanf(fp, "%d %*s", &n); // times
  fscanf(fp, "%s %*s", &fname); // times

  fclose(fp);
  strcat(fn, fname); // 결과파일 이름 설정
  strcat(query, fname);// 쿼리문 작성
  strcat(query, "'");

  printf("fn : %s\n",fn);
  printf("fname : %s\n", fname);
  printf("period : %d\n", period);
  printf("polarity : %d\n", pol);
  printf("thr : %d\n", thr);
  printf("times : %d\n", n);

  setPeriod(period);
  setPOL(pol);
  setTHR(thr);

  stop();
  reset();
  start();


  while(run() == 0) {
    start();
    usleep(1000);
  }
  if (run() == 1) printf("start\n");


  fr = fopen(fn, "w");

  for(i = 0; i < n; i++) {
    //usleep(1000);
    //data_size = 0;
    data_size = datasize();
    printf("run : %d\n", i);
    while(!data_size) {
      if (run() == 0) {
        printf("stopped\n");
        start();
      }
      usleep(1000);
      data_size = datasize();
    }
    printf("data_size : %d\n", data_size); 
    readDATA(1,data);
    printf("%d/%d cnt : %d\n", i+1, n, data[0]);
    fprintf(fr, "%d\n", data[0]);
    fflush(fr);
  }


  fclose(fr);

  stop();
  reset();
  if (run() == 0) printf("done\n");

  

  query_stat = mysql_query(connection, query);
  printf("query : %s\n", query);
    if (query_stat != 0)
    {
        fprintf(stderr, "Mysql query error : %s", mysql_error(&conn));
        return 1;
    }

  mysql_close(connection);
  mysql_close(&conn);
}
