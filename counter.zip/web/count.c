//#include "iostream"
#include "stdio.h"
#include "spi.h"
//#include "string.h"

//using namespace std;

int main() {

  FILE *fp;
  FILE *fc;
  int i;
  int n;
  int data[4096] = {0};
  int data_size;
  char fname[30];
  char aaa[30];
  char fn[50] = "/home/pi/Desktop/web/data/";

  int period ;//second
  int thr ;//0~4095
  int pol ;//0 is negative, 1 is positive

  setup_io();

  fp = fopen("./setting.txt", "rt");
  fscanf(fp, "%d %*s", &period); // period
  fscanf(fp, "%d %*s", &pol);  // polarity
  fscanf(fp, "%d %*s", &thr); // 
  fscanf(fp, "%d %*s", &n); // times
  fscanf(fp, "%s %*s", &fname); // times

  fclose(fp);
  strcat(fn, fname); // 결과파일 이름 설정

  printf("fn : %s\n",fn);
  printf("fname : %s\n", fname);
  printf("period : %d\n", period);
  printf("polarity : %d\n", pol);
  printf("thr : %d\n", thr);
  printf("times : %d\n", n);

  setPeriod(period);
  setPOL(pol);
  setTHR(thr);

  stop();
  reset();
  start();


  while(run() == 0) {
    start();
    usleep(1000);
  }
  if (run() == 1) printf("start\n");


  fc = fopen(fn, "wt");

  for(i = 0; i < n; i++) {
    usleep(1000);
    data_size = datasize();
    while(!data_size) {
      if (run() == 0) {
        printf("stopped\n");
        start();
      }
      usleep(1000);
      data_size = datasize();
    }
    printf("data_size : %d\n", data_size); 
    readDATA(1,data);
    printf("%d/%d cnt : %d\n", i+1, n, data[0]);
    fprintf(fc, "%d\n", data[0]);
  }


  fclose(fc);

  stop();
  reset();
  if (run() == 0) printf("done\n");

}
