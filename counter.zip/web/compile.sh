sync
echo gcc -o update_bit update_bit.c spi.c spi.h -lwiringPi
gcc -o update_bit update_bit.c spi.c spi.h -lwiringPi
echo gcc -o run run.c spi.c spi.h -lwiringPi
gcc -o run run.c spi.c spi.h -lwiringPi
echo gcc -o count count.c spi.c spi.h -lwiringPi
gcc -o count count.c spi.c spi.h -lwiringPi
